﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Документ без названия</title>
</head>

<body>

<?php 
if (isset ($_POST['pogelanie']))
{
	$pogelanie = $_POST['pogelanie'];
	}
$db = mysql_connect ("localhost","user","1234");
mysql_select_db ("my_db",$db);
$result = mysql_query ("insert into пожелания (pogelanie) values ('$pogelanie')");
if ($result == 'true')
{
	echo "Пожелание успешно отправлено!";
	}
else 
{
	echo "Пожелание не отправлено!";
	}
?>

</body>
</html>