﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Галерея дизайна</title>
<link href="multibox.css" rel="stylesheet" type="text/css" /> 
<link rel="stylesheet" href="ie6.css" type="text/css" media="all" />
<script type="text/javascript" src="mootools.js"></script> 
<script type="text/javascript" src="overlay.js"></script> 
<script type="text/javascript" src="multibox.js"></script>
</head>

<body>

<div id="main_container">
<div id="container"> 
<div id="example"> 

<a href="photos/1_1diz.jpg" id="mb1" class="mb" title="Готика"><img src="photos/1_1diz_mini.jpg" alt="" border="0" /></a> 
<div class="multiBoxDesc mb1"></div>
 
<a href="photos/2_1diz.jpg" id="mb2" class="mb" title="Барокко"><img src="photos/2_1diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb2"></div> 

<a href="photos/3diz.jpg" id="mb3" class="mb" title="Классицизм"><img src="photos/3diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb3"></div>

<a href="photos/4diz.jpg" id="mb4" class="mb" title="Модерн"><img src="photos/4diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb4">

  <a href="photos/5diz.jpg" id="mb5" class="mb" title="Ар-Деко"><img src="photos/5diz_mini.jpg" alt="" border="0" /></a></div>
<div class="multiBoxDesc mb5"></div> 
 
<a href="photos/6diz.jpg" id="mb6" class="mb" title="Минимализм"><img src="photos/6diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb6"></div> 
 
<a href="photos/7diz.jpg" id="mb7" class="mb" title="Кантри"><img src="photos/7diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb7"></div> 

<br /><br />
 
<a href="photos/8diz.jpg" id="mb8" class="mb" title="Хай-тек"><img src="photos/8diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb8"></div> 

<a href="photos/9diz.jpg" id="mb9" class="mb" title="Эклектика"><img src="photos/9diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb9"></div> 

<a href="photos/10diz.jpg" id="mb10" class="mb" title="Восточный стиль"><img src="photos/10diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb10"></div> 

<a href="photos/11_1diz.jpg" id="mb11" class="mb" title="Колонниальный стиль"><img src="photos/11_1diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb11"></div> 

<a href="photos/12_2diz.jpg" id="mb12" class="mb" title="Тайский интерьер"><img src="photos/12_2diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb12"></div> 

<a href="photos/13_2diz.jpg" id="mb13" class="mb" title="Японский интерьер"><img src="photos/13_2diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb13"></div> 

<br /><br />

<a href="photos/14_2diz.jpg" id="mb14" class="mb" title="Китайский интерьер"><img src="photos/14_2diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb14"></div> 

<a href="photos/15_1diz.jpg" id="mb15" class="mb" title="Индийский интерьер"><img src="photos/15_1diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb15"></div> 

<a href="photos/16_3diz.jpg" id="mb16" class="mb" title="Нордический интерьер"><img src="photos/16_3diz_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb16"></div> 

 
</div> 
</div>
</div>

<script type="text/javascript">	
var box = {};			
window.addEvent('domready', function(){			
box = new MultiBox('mb', {descClassName: 'multiBoxDesc', useOverlay: true});
});		
</script>

</body>

</html>