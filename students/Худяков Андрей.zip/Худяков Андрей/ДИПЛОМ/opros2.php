<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Понравился ли вам сайт?</title>
</head>

<body style="background-image:url(images/opros3.jpg); color:#FFF">
<div>
<p style="font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; font-size:14px; font-weight:bold;">
Ваше пожелание доставлено администратору! Спасибо за принятие участия в опросе.
</p>
</div>
</body>

</html>
