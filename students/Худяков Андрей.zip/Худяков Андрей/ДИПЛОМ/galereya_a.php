﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Галерея архитектуры</title>
<link href="multibox.css" rel="stylesheet" type="text/css" /> 
<link rel="stylesheet" href="ie6.css" type="text/css" media="all" />
<script type="text/javascript" src="mootools.js"></script> 
<script type="text/javascript" src="overlay.js"></script> 
<script type="text/javascript" src="multibox.js"></script>
</head>

<body>

<div id="main_container">
<div id="container"> 
<div id="example"> 
<a href="photos/Neswigskiy kostel.jpg" id="mb1" class="mb" title="Несвижский костел иезуитов"><img src="photos/Neswigskiy kostel_mini.jpg" alt="" border="0" /></a> 
<div class="multiBoxDesc mb1"></div> 
<a href="photos/Soborniy ansambl.jpg" id="mb2" class="mb" title="Соборный ансамбль"><img src="photos/Soborniy ansambl_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb2"></div> 
<a href="photos/baur_dom.jpg" id="mb3" class="mb" title="Баурский дом в Санкт-Петербурге"><img src="photos/baur_dom_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb3"></div>
<a href="photos/Mirskiy_zamok 1.jpg" id="mb4" class="mb" title="Мирский замок"><img src="photos/Mirskiy_zamok 1_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb4">
  <a href="photos/borgeze2.jpg" id="mb5" class="mb" title="Вилла Боргезе"><img src="photos/borgeze2_mini.jpg" alt="" border="0" /></a></div>
<div class="multiBoxDesc mb5"></div>  
<a href="photos/borgeze.jpg" id="mb6" class="mb" title="Вилла Боргезе"><img src="photos/borgeze_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb6"></div>  
<a href="photos/dom_banketov.jpg" id="mb7" class="mb" title="Дом Банкетов в Лондоне"><img src="photos/dom_banketov_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb7"></div> 

<br /><br />
 
<a href="photos/hram_dimetry_elevsin.jpg" id="mb8" class="mb" title="Храм Диметры в Элевсине"><img src="photos/hram_dimetry_elevsin_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb8"></div> 

<a href="photos/dvorez_dogej.jpg" id="mb9" class="mb" title="Дворец Дожей в Риме"><img src="photos/dvorez_dogej_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb9"></div> 

<a href="photos/gorb_most.jpg" id="mb10" class="mb" title="Горбатый мост"><img src="photos/gorb_most_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb10"></div> 

<a href="photos/hram_sv_sofii.jpg" id="mb11" class="mb" title="Храм Святой Софии"><img src="photos/hram_sv_sofii_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb11"></div> 

<a href="photos/parfenon.jpg" id="mb12" class="mb" title="Парфенон"><img src="photos/parfenon_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb12"></div> 

<a href="photos/vitruvian-man.jpg" id="mb13" class="mb" title="Витрувианский человек"><img src="photos/vitruvian-man_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb13"></div> 

<br /><br />

<a href="photos/Postroyka v st_organika.jpg" id="mb14" class="mb" title="Постройка в стиле органики"><img src="photos/Postroyka v st_organika_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb14"></div> 

</div> 
</div>
</div>

<script type="text/javascript">	
var box = {};			
window.addEvent('domready', function(){			
box = new MultiBox('mb', {descClassName: 'multiBoxDesc', useOverlay: true});
});		
</script>

</body>

</html>