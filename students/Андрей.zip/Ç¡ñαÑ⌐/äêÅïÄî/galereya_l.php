﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Галерея ландшафта</title>
<link href="multibox.css" rel="stylesheet" type="text/css" /> 
<link rel="stylesheet" href="ie6.css" type="text/css" media="all" />
<script type="text/javascript" src="mootools.js"></script> 
<script type="text/javascript" src="overlay.js"></script> 
<script type="text/javascript" src="multibox.js"></script>
</head>

<body>

<div id="main_container">
<div id="container"> 
<div id="example"> 

<a href="photos/Hampton Court.jpg" id="mb1" class="mb" title="Дворец Хэмптон–Корт"><img src="photos/Hampton Court_mini.jpg" alt="" border="0" /></a> 
<div class="multiBoxDesc mb1"></div>
 
<a href="photos/Hampton Court_2.jpg" id="mb2" class="mb" title="Дворец Хэмптон–Корт"><img src="photos/Hampton Court_2_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb2"></div> 

<a href="photos/Hampton Court_6.jpg" id="mb3" class="mb" title="Дворец Хэмптон–Корт"><img src="photos/Hampton Court_6_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb3"></div>

<a href="photos/Hampton Court_7.jpg" id="mb4" class="mb" title="Дворец Хэмптон–Корт"><img src="photos/Hampton Court_7_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb4">

<a href="photos/Longwood.jpg" id="mb5" class="mb" title="Сады Лонгвуда"><img src="photos/Longwood_mini.jpg" alt="" border="0" /></a></div>
<div class="multiBoxDesc mb5"></div> 
 
<a href="photos/Longwood_4.jpg" id="mb6" class="mb" title="Сады Лонгвуда"><img src="photos/Longwood_4_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb6"></div> 
 
<a href="photos/Sad_Ladju_Ohotnik.JPG" id="mb7" class="mb" title="Сад Ладью, Охотник"><img src="photos/Sad_Ladju_Ohotnik_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb7"></div> 

<br /><br />
 
<a href="photos/Sady_Versalya_2.jpg" id="mb8" class="mb" title="Дворцово-парковый комплекс Версаль"><img src="photos/Sady_Versalya_2_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb8"></div> 

<a href="photos/Sady_Versalya_3.jpg" id="mb9" class="mb" title="Дворцово-парковый комплекс Версаль"><img src="photos/Sady_Versalya_3_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb9"></div> 

<a href="photos/Vis_sady_Semiramidy.jpeg" id="mb10" class="mb" title="Висячие сады Семирамиды"><img src="photos/Vis_sady_Semiramidy_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb10"></div> 

<a href="photos/Zentr_botan_sad_Belarus.jpg" id="mb11" class="mb" title="Центральный ботанический сад Беларуси"><img src="photos/Zentr_botan_sad_Belarus_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb11"></div> 

<a href="photos/Zentr_botan_sad_Belarus_5.jpg" id="mb12" class="mb" title="Центральный ботанический сад Беларуси"><img src="photos/Zentr_botan_sad_Belarus_5_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb12"></div> 

<a href="photos/Zentr_botan_sad_Belarus_7.jpg" id="mb13" class="mb" title="Центральный ботанический сад Беларуси"><img src="photos/Zentr_botan_sad_Belarus_7_mini.jpg" alt="" border="0" /></a>
<div class="multiBoxDesc mb13"></div> 
 
</div> 
</div>
</div>

<script type="text/javascript">	
var box = {};			
window.addEvent('domready', function(){			
box = new MultiBox('mb', {descClassName: 'multiBoxDesc', useOverlay: true});
});		
</script>

</body>

</html>